#!/bin/bash


################################################################################
#  run_test.sh
#
#  This script automates the benchmarking of RAMSES file reading performance
#  using the Mera.jl package under various multithreading and garbage collection (GC)
#  configurations. It is intended to be used together with the Julia scripts in
#  this folder (e.g., run_test.jl and run_test_plots.jl).
#
#  Usage:
#    - Place this script together with 'run_test.jl' in a directory.
#    - Properly configure this script and the 'run_test.jl' file.
#    - The directory needs to have a Julia project environment.
#    - Install Mera and the related benchmark dependencies.
#    - Run: bash run_test.sh
#
#  Features:
#    - Tests a range of compute:GC thread settings (e.g., 1:1, 2:1, 4:2, ...).
#    - Logs start and end times for each configuration.
#    - Saves summary results to 'thread_statistics.csv'.
#    - Saves detailed results to 'thread_stats_*t_*gc_*.json' files.
#
#  Notes:
#    - Adjust the 'configs' array to test different thread settings as needed.
#    - Results can be visualized and analyzed using the provided Julia scripts.
#
#  Origin: https://github.com/ManuelBehrendt/Mera.jl
#  Author: Manuel Behrendt
#  Date: July 2025
#
################################################################################

# Array of thread configurations to test
# Format: "compute_threads:gc_threads"
configs=(
    "1:1"
    "2:1" 
    "4:2"
    "8:4"
    "16:8"
    "32:16"
    "64:16"
)

echo "=== MERA Thread Configuration Testing ==="
echo "Date: $(date)"
echo "Testing ${#configs[@]} configurations"
echo

# Test each configuration
for config in "${configs[@]}"; do
    IFS=':' read -r compute_threads gc_threads <<< "$config"
    
    echo "=========================================="
    echo "Testing: $compute_threads compute, $gc_threads GC threads"
    echo "Started at: $(date)"
    echo "=========================================="
    
    # Run Julia with specific thread configuration
    # For juliaup managed installations, use: julia +1.11 -t $compute_threads --gcthreads $gc_threads run_test.jl
    # For standard installations, use the line below:
    julia --project=. -t $compute_threads --gcthreads $gc_threads run_test.jl
    
    echo "Completed at: $(date)"
    echo
    
    # Brief pause between configurations
    sleep 5
done

echo "=========================================="
echo "All thread configurations tested!"
echo "Results saved in thread_statistics.csv"
echo "Individual files: thread_stats_*t_*gc_*.json"
echo "=========================================="


