################################################################################
#  run_test.jl
#
#  This script runs a RAMSES file reading benchmark using the Mera.jl package.
#  It is intended to be used together with the plotting and analysis scripts in
#  this folder (e.g., run_test_plots.jl and run_test.sh).
#
#  Usage:
#    - Set the correct simulation folder and output number below.
#    - Run this script in a Julia environment with Mera installed.
#
#  Origin: https://github.com/ManuelBehrendt/Mera.jl
#  Author: Manuel Behrendt
#  Date: July 2025
#
################################################################################

import Pkg; Pkg.activate(".")
using Mera

path = "/simulation/folder" # RAMSES simulation folder (outputs)
output_number = 250 # number of the RAMSES snapshot
run_reading_benchmark(output_number, path)