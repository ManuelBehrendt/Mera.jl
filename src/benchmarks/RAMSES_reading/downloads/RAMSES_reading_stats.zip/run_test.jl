################################################################################
#  run_test.jl
#
#  This script runs a RAMSES file reading benchmark using the Mera.jl package.
#  It is intended to be used together with the plotting and analysis scripts in
#  this folder (e.g., run_test_plots.jl and run_test.sh).
#
#  Usage:
#    - Set the correct simulation folder and output number below.
#    - Run this script in a Julia environment with Mera installed.
#
#  Origin: https://github.com/ManuelBehrendt/Mera.jl
#  Author: Manuel Behrendt
#  Date: July 2025
#
################################################################################

import Pkg; Pkg.activate(".")
using Mera

# EDIT THESE PATHS FOR YOUR SYSTEM:
# Examples of typical RAMSES output directories:
path = "/home/user/simulations/galaxy_formation/output/"   # RAMSES simulation folder (outputs)
# path = "/Users/username/research/ramses_data/output/"     # macOS example  
# path = "C:\\Users\\username\\Documents\\simulations\\output\\"  # Windows example
# path = "/data/simulations/ramses_run_001/output/"         # Server example

output_number = 250  # number of the RAMSES snapshot (adjust to available snapshots)
run_reading_benchmark(output_number, path)