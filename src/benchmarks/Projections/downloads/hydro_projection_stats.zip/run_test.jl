################################################################################
#  run_test.jl
#
#  Comprehensive hydro projection benchmark system for AMR simulation data.
#  Analyzes multi-threading performance, memory scaling, and projection efficiency
#  across single-variable and multi-variable AMR hydro projections.
#
#  Purpose:
#    • Evaluate threading scalability for hydro projection operations
#    • Compare single vs multi-variable projection performance characteristics  
#    • Generate robust statistical performance data (10 runs per configuration)
#    • Create benchmark results with comprehensive error analysis
#
#  Benchmark Methodology:
#    • Single-Variable Test: Surface density projection (:sd → Msun/pc²)
#    • Multi-Variable Test: 10 simultaneous variable projections
#    • Thread scaling: 1 to system maximum (automatically detected)
#    • Statistical robustness: 10 repetitions per configuration with CV analysis
#    • Quality control: Success rate monitoring and outlier detection
#
#  System Integration:
#    - Compatible with RAMSES AMR simulation data via Mera.jl
#    - Automatic thread count detection and system capability filtering
#    - Comprehensive output: CSV (analysis), JSON (structured), TXT (summary)
#    - Seamless integration with plot_results.jl for visualization
#
#  Usage Workflow:
#    1. Configure simulation paths and output number below 
#    2. Start Julia with maximum threads: julia --threads=auto
#    3. Execute: julia run_test.jl
#    4. Visualize: include("plot_results.jl"); plot_benchmark_results("results.csv")
#
#  Origin: https://github.com/ManuelBehrendt/Mera.jl
#  Author: Manuel Behrendt  
#  Date: July 2025
#
################################################################################

# ═══════════════════════════════════════════════════════════════════════════════
#  ENVIRONMENT SETUP & SYSTEM VERIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

import Pkg; Pkg.activate(".")
using Mera

println("="^80)
println("MERA HYDRO PROJECTION BENCHMARK SYSTEM")
println("="^80)
println("Julia threads available: $(Threads.nthreads())")
println("System CPU cores: $(Sys.CPU_THREADS)")

# Threading optimization check
if Threads.nthreads() < Sys.CPU_THREADS
    println("⚠️  Performance Warning: Start Julia with --threads=auto for optimal threading")
    println("   Current: $(Threads.nthreads()) threads | Recommended: $(Sys.CPU_THREADS)+ threads")
else
    println("✅ Threading configuration optimal for benchmark execution")
end
println()

# ═══════════════════════════════════════════════════════════════════════════════
#  SIMULATION DATA CONFIGURATION - UPDATE FOR YOUR DATA
# ═══════════════════════════════════════════════════════════════════════════════

println("📂 Loading hydro simulation data...")

# ┌─────────────────────────────────────────────────────────────────────────────
# │ REQUIRED: Set your simulation path and output number
# └─────────────────────────────────────────────────────────────────────────────

hydro_path = "/folder/to/mera/files/"   # 🔧 Update: Path to your RAMSES simulation directory
output_number = 300                     # 🔧 Update: Output number to benchmark (e.g., 300)

# Load hydro data using Mera's standard data loading function
gas_data = loaddata(output_number, hydro_path, :hydro)

# ┌─────────────────────────────────────────────────────────────────────────────
# │ ALTERNATIVE: Load specific subregion for targeted benchmarking
# │ Uncomment and configure the following for region-specific analysis:
# └─────────────────────────────────────────────────────────────────────────────
# info = getinfo(output_number, hydro_path) 
# gas_data = gethydrodata(info, lmax=10, xrange=[-20,20], yrange=[-20,20], zrange=[-20,20])

println("✅ Hydro data loaded successfully!")
println("   Data size: $(length(gas_data.data)) cells")
println("   Available variables: $(join(string.(propertynames(gas_data.data)), ", "))")
println()

# ═══════════════════════════════════════════════════════════════════════════════
#  BENCHMARK CONFIGURATION & PARAMETERS
# ═══════════════════════════════════════════════════════════════════════════════

# ┌─────────────────────────────────────────────────────────────────────────────
# │ Thread Configuration: Automatic system-aware thread count selection
# └─────────────────────────────────────────────────────────────────────────────

# Comprehensive thread count range for thorough performance analysis
thread_counts = [1, 2, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 56, 64]

# Filter to system capabilities (max 2× CPU cores, capped at 64 for practicality)
thread_counts = filter(x -> x <= min(Sys.CPU_THREADS * 2, 64), thread_counts)

# ┌─────────────────────────────────────────────────────────────────────────────
# │ Statistical Configuration: Robust performance measurement
# └─────────────────────────────────────────────────────────────────────────────

n_runs = 10  # Repetitions per thread configuration (10 runs for robust statistics)

# ┌─────────────────────────────────────────────────────────────────────────────
# │ Output Configuration: Timestamped result files  
# └─────────────────────────────────────────────────────────────────────────────

using Dates
output_file = "benchmark_results_$(Dates.format(Dates.now(), "yyyymmdd_HHMMSS"))"

println("BENCHMARK CONFIGURATION SUMMARY:")
println("  📊 Thread counts to test: $thread_counts")
println("  🔄 Statistical runs per config: $n_runs (robust 10-run methodology)")
println("  📁 Output file prefix: $output_file") 
println("  📈 Generated files: CSV (spreadsheet), JSON (structured), TXT (summary)")
println()

# ═══════════════════════════════════════════════════════════════════════════════
#  BENCHMARK EXECUTION - AUTOMATED PERFORMANCE ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

println("🚀 Initiating comprehensive hydro projection benchmark...")
println("   This will test both single-variable and multi-variable projections")
println("   across the configured thread counts with robust statistical analysis.")
println()

# Execute benchmark using Mera's comprehensive projection benchmark function
# This function performs:
#   • Single-variable projection: Surface density (:sd → Msun/pc²)  
#   • Multi-variable projection: 10 simultaneous hydro variables
#   • Statistical analysis: 10 runs per configuration with CV analysis
#   • Quality monitoring: Success rate tracking and outlier detection
#   • Memory profiling: Peak memory usage and garbage collection analysis

results = benchmark_projection_hydro(gas_data, thread_counts, n_runs, output_file)

# ═══════════════════════════════════════════════════════════════════════════════
#  RESULTS SUMMARY & NEXT STEPS
# ═══════════════════════════════════════════════════════════════════════════════

println()
println("🎉 Benchmark execution completed successfully!")
println()
println("📊 RESULTS SAVED AS:")
println("   • $(output_file).csv         → Spreadsheet data for analysis")
println("   • $(output_file).json        → Structured data for programmatic access")  
println("   • $(output_file)_summary.txt → Human-readable performance report")
println()
println("� VISUALIZATION WORKFLOW:")
println("   1. Install plotting packages:")
println("      julia> import Pkg")
println("      julia> Pkg.add([\"CairoMakie\", \"CSV\", \"DataFrames\"])")
println()
println("   2. Load visualization system:")
println("      julia> include(\"plot_results.jl\")")
println()
println("   3. Generate performance dashboard:")
println("      julia> plot_benchmark_results(\"$(output_file).csv\")")
println()
println("   📋 This creates a comprehensive 2×2 performance dashboard with:")
println("      • Execution time scaling (log scale) with error bars")
println("      • Speedup analysis vs ideal threading performance")
println("      • Threading efficiency analysis with 100% reference")
println("      • Memory usage scaling across thread configurations")
println("      • Statistical uncertainty analysis for all metrics")
println()
println("✅ Benchmark analysis complete - ready for performance visualization!")
